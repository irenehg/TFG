#include "xaxidma.h"
#include "xparameters.h"
#include "xil_cache.h"
#include "xil_types.h"
#include "xscugic.h"
#include "xuartps.h"
#include "xaxivdma.h"
#include "xgpio.h"
#include "stdio.h"
#include "ff.h"
#include "xtime_l.h"

#define HSize 800
#define VSize 600
#define FrameSize HSize*VSize*3
#define totalImagenes 4

u32 checkIdle(u32 baseAddress,u32 offset);
static void imageProcISR(void *CallBackRef);
static void dmaReceiveISR(void *CallBackRef);
static void ReadCallBack(void *CallbackRef, u32 Mask);
static void ErrorCallBack(void *CallbackRef, u32 Mask);
int drawImage(u32 displayHSize,u32 displayVSize,u32 imageHSize,u32 imageVSize,u32 hOffset, u32 vOffset,char *imagePointer);
static int SD_Init();
static int readFile(char *file, u32 DestinationAddress);

unsigned char Buffer[FrameSize]; //si la imagen fuese de 800x600 bastaria con copiarla en este buffer
int done=0;
char *imageData;
u8 *dummyLines;
XScuGic IntcInstance;
FATFS filesystem; //FAT filesystem
int imgIndex = 0; // �ndice para el carrusel de im�genes


int main(){
    u32 status;


	/************** CONFIGURACIONES VDMA **************/

	XAxiVdma_Config *myVdmaConfig;
	XAxiVdma myVdma;
	XAxiVdma_DmaSetup ReadCfg; //estructura para definir el tama�o del frame
	u32 Addr; //direccion de comienzo para el buffer
	int ind;

	myVdmaConfig = XAxiVdma_LookupConfig(XPAR_AXI_VDMA_0_DEVICE_ID);
	status = XAxiVdma_CfgInitialize(&myVdma, myVdmaConfig, myVdmaConfig->BaseAddress);
	if(status != XST_SUCCESS){
		print("VDMA initialization failed\n");
		return -1;
	}

	ReadCfg.VertSizeInput = VSize; //numero de pixels
	ReadCfg.HoriSizeInput = HSize*3; //numero de bytes
	ReadCfg.Stride = HSize*3;
	ReadCfg.FrameDelay = 0;
	ReadCfg.EnableCircularBuf = 1;
	ReadCfg.EnableSync = 1;
	ReadCfg.PointNum = 0;
	ReadCfg.EnableFrameCounter = 0;
	ReadCfg.FixedFrameStoreAddr = 0;

	status = XAxiVdma_DmaConfig(&myVdma, XAXIVDMA_READ, &ReadCfg); //XAXIVDMA_READ  /**< DMA transfer from memory */
	if(status != XST_SUCCESS){
		print("Write channel config failed\n");
		return -1;
	}

	Addr = (u32)&(Buffer[0]);
	//Initialize starting addresses
	for(ind = 0; ind < myVdma.MaxNumFrames; ind++){   //si solo tenemos 1 frame buffer solo lo recorre una vez
		ReadCfg.FrameStoreStartAddr[ind] = Addr;
		Addr += FrameSize;
	}

	status = XAxiVdma_DmaSetBufferAddr(&myVdma, XAXIVDMA_READ, ReadCfg.FrameStoreStartAddr);
	if(status != XST_SUCCESS){
		print("Set read channel buffer address failed\n");
		return -1;
	}

	XAxiVdma_IntrEnable(&myVdma, XAXIVDMA_IXR_COMPLETION_MASK, XAXIVDMA_READ); //interrupcion de completado




	/************** CONFIGURACIONES DMA **************/

	XAxiDma_Config *myDmaConfig;
	XAxiDma myDma;

	myDmaConfig = XAxiDma_LookupConfig(XPAR_AXI_DMA_0_DEVICE_ID);
	status = XAxiDma_CfgInitialize(&myDma, myDmaConfig);
	if(status != XST_SUCCESS){
		print("DMA initialization failed\n");
		return -1;
	}

	XAxiDma_IntrEnable(&myDma, XAXIDMA_IRQ_IOC_MASK, XAXIDMA_DEVICE_TO_DMA);




	/************** CONFIGURACIONES GPIO **************/

	XGpio input_gpio;

	status = XGpio_Initialize(&input_gpio, XPAR_AXI_GPIO_0_DEVICE_ID); //initialize input XGpio variable
	if(status != XST_SUCCESS){
			print("GPIO initialization failed\n");
			return -1;
	}
	XGpio_SetDataDirection(&input_gpio,1,1);




	/************** CONFIGURACIONES INTERRUPCIONES **************/

	XScuGic_Config *IntcConfig;

	IntcConfig = XScuGic_LookupConfig(XPAR_PS7_SCUGIC_0_DEVICE_ID);
	status =  XScuGic_CfgInitialize(&IntcInstance, IntcConfig, IntcConfig->CpuBaseAddress);
	if(status != XST_SUCCESS){
		print("Interrupt controller initialization failed..");
		return -1;
	}

	//*** Intrerrupcion Processing Image ***//
	XScuGic_SetPriorityTriggerType(&IntcInstance,XPAR_FABRIC_IMAGEPROCESSINGTOP_0_O_INTERRUPT_INTR,0xA0,3);
	status = XScuGic_Connect(&IntcInstance,XPAR_FABRIC_IMAGEPROCESSINGTOP_0_O_INTERRUPT_INTR,(Xil_InterruptHandler)imageProcISR,(void *)&myDma);
	if(status != XST_SUCCESS){
		print("Interrupt connection failed");
		return -1;
	}
	XScuGic_Enable(&IntcInstance,XPAR_FABRIC_IMAGEPROCESSINGTOP_0_O_INTERRUPT_INTR);
	//*** Intrerrupcion DMA ***//
	XScuGic_SetPriorityTriggerType(&IntcInstance,XPAR_FABRIC_AXI_DMA_0_S2MM_INTROUT_INTR,0xA1,3);
	status = XScuGic_Connect(&IntcInstance,XPAR_FABRIC_AXI_DMA_0_S2MM_INTROUT_INTR,(Xil_InterruptHandler)dmaReceiveISR,(void *)&myDma);
	if(status != XST_SUCCESS){
		print("Interrupt connection failed");
		return -1;
	}
	XScuGic_Enable(&IntcInstance,XPAR_FABRIC_AXI_DMA_0_S2MM_INTROUT_INTR);
	//*** Intrerrupcion VDMA ***//
	XScuGic_SetPriorityTriggerType(&IntcInstance,XPAR_FABRIC_AXI_VDMA_0_MM2S_INTROUT_INTR,0xA2,3);
	status = XScuGic_Connect(&IntcInstance,XPAR_FABRIC_AXI_VDMA_0_MM2S_INTROUT_INTR,(Xil_InterruptHandler)XAxiVdma_ReadIntrHandler,(void *)&myVdma);
	if(status != XST_SUCCESS){
		print("Interrupt connection failed");
		return -1;
	}
	XScuGic_Enable(&IntcInstance,XPAR_FABRIC_AXI_VDMA_0_MM2S_INTROUT_INTR);
		// Call-back functions
	XAxiVdma_SetCallBack(&myVdma,XAXIVDMA_HANDLER_GENERAL, ReadCallBack, &myVdma, XAXIVDMA_READ);
	XAxiVdma_SetCallBack(&myVdma,XAXIVDMA_HANDLER_ERROR, ErrorCallBack, &myVdma, XAXIVDMA_READ);

	Xil_ExceptionInit();
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,(Xil_ExceptionHandler)XScuGic_InterruptHandler,(void *)&IntcInstance);
	Xil_ExceptionEnable();




	/************** OBTENEMOS IMAGEN **************/

    int imgVSize = 512;
    int imgHSize = 512;
	int imageSize = imgHSize*imgVSize;
	char *sobelData[totalImagenes];
	XTime lastTime, currentTime;
	char *imageNames[totalImagenes] = {"im1.bin", "im2.bin", "im3.bin", "im4.bin"};
	u32 anterior = 0;  // Estado anterior de los botones
	int displaySobel = 0;  // Flag para alternar entre imagen normal y con filtro
	int index = totalImagenes+1;



	imageData = malloc(sizeof(u8)*imageSize);
	dummyLines = malloc(sizeof(u8)*(imgHSize+imgHSize));

	// Allocate memory for each Sobel image
	for (int i = 0; i < totalImagenes; i++) {
	    sobelData[i] = malloc(sizeof(u8)*imageSize);
	}

	status = SD_Init();
	if(status != XST_SUCCESS){
		print("Initialization of SD failed");
		return -1;
	}

	for(int i=0; i<512+512; i++){
			dummyLines[i] = 0;
		}

	status = XAxiVdma_DmaStart(&myVdma, XAXIVDMA_READ);
	if(status != XST_SUCCESS){
		print("DMA start failed");
	   		return -1;
	}

	while(1) {
		  	// Leer y cargar la imagen actual desde la SD
			status = readFile(imageNames[imgIndex], (u32)imageData);

		    // Enviar la imagen procesada o normal al monitor seg�n el flag displaySobel
		    if (displaySobel ) {
		    	if (index != imgIndex){
		    		// Mandar la imagen a la DMA para procesamiento
		    		status = XAxiDma_SimpleTransfer(&myDma, (u32)sobelData[imgIndex], imageSize, XAXIDMA_DEVICE_TO_DMA);
		    		status = XAxiDma_SimpleTransfer(&myDma, (u32)imageData, 4*512, XAXIDMA_DMA_TO_DEVICE);



		    		// Esperar hasta que la DMA termine de procesar la imagen
		    		while(!done){ }
		    		index = imgIndex;
		    	}
		        drawImage(HSize, VSize, imgHSize, imgVSize, (HSize - imgHSize) / 2, (VSize - imgVSize) / 2, sobelData[imgIndex]);

		    } else {

		        drawImage(HSize, VSize, imgHSize, imgVSize, (HSize - imgHSize) / 2, (VSize - imgVSize) / 2, imageData);

		    }


		    // Leer el estado de los botones
		    u32 button_data = XGpio_DiscreteRead(&input_gpio, 1);

		    // Solo act�a si el estado de los botones ha cambiado
		    if(anterior != button_data){
		        anterior = button_data;

		        switch(anterior){
		            case 1:  // Si se pulsa el bot�n 1, muestra la imagen normal
		                displaySobel = 0;
		                break;
		            case 2:  // Si se pulsa el bot�n 2, muestra la imagen procesada (con filtro)
		                displaySobel = 1;
		                break;
		            default:
		                break;
		        }
		    }

		    // Controlar el tiempo de actualizaci�n de la imagen cada 5 segundos
		    XTime_GetTime(&currentTime);
		    if (((currentTime - lastTime) / COUNTS_PER_SECOND) >= 5) {
		        imgIndex = (imgIndex + 1) % totalImagenes;  // Cambiar al siguiente �ndice de imagen
		        lastTime = currentTime;  // Reiniciar el temporizador

		    }
		}
}


u32 checkIdle(u32 baseAddress,u32 offset){
	u32 status;
	status = (XAxiDma_ReadReg(baseAddress,offset))&XAXIDMA_IDLE_MASK;
	return status;
}


static void imageProcISR(void *CallBackRef){
	static int i=4;
	int status;
	XScuGic_Disable(&IntcInstance,XPAR_FABRIC_IMAGEPROCESSINGTOP_0_O_INTERRUPT_INTR);

	status = checkIdle(XPAR_AXI_DMA_0_BASEADDR,0x4);
	while(status == 0)
		status = checkIdle(XPAR_AXI_DMA_0_BASEADDR,0x4);

	if(i<514){
		if(i<514){
			status = XAxiDma_SimpleTransfer((XAxiDma *)CallBackRef,(u32)&imageData[i*512],512,XAXIDMA_DMA_TO_DEVICE);
			i++;
		}
		else{  //dummy lines
			status = XAxiDma_SimpleTransfer((XAxiDma *)CallBackRef,(u32)&dummyLines[0],512,XAXIDMA_DMA_TO_DEVICE);
			i++;
		}
	}
	XScuGic_Enable(&IntcInstance,XPAR_FABRIC_IMAGEPROCESSINGTOP_0_O_INTERRUPT_INTR);
}


static void dmaReceiveISR(void *CallBackRef){
	XAxiDma_IntrDisable((XAxiDma *)CallBackRef, XAXIDMA_IRQ_IOC_MASK, XAXIDMA_DEVICE_TO_DMA);
	XAxiDma_IntrAckIrq((XAxiDma *)CallBackRef, XAXIDMA_IRQ_IOC_MASK, XAXIDMA_DEVICE_TO_DMA);
	done = 1;
	XAxiDma_IntrEnable((XAxiDma *)CallBackRef, XAXIDMA_IRQ_IOC_MASK, XAXIDMA_DEVICE_TO_DMA);
}

static void ReadCallBack(void *CallbackRef, u32 Mask)
{
	/* User can add his code in this call back function */
	//print("Read Call back function is called\r\n");
}

static void ErrorCallBack(void *CallbackRef, u32 Mask)
{
	/* User can add his code in this call back function */
	print("Read Call back Error function is called\r\n");

}


int drawImage(u32 displayHSize,u32 displayVSize,u32 imageHSize,u32 imageVSize,u32 hOffset, u32 vOffset,char *imagePointer){
	for(int i=0;i<displayVSize;i++){
		for(int j=0;j<displayHSize;j++){
			if(i<vOffset || i >= vOffset+imageVSize){
				Buffer[(i*displayHSize*3)+(j*3)]   = 0x00;
			    Buffer[(i*displayHSize*3)+(j*3)+1] = 0x00;
			    Buffer[(i*displayHSize*3)+(j*3)+2] = 0x00;
			}
			else if(j<hOffset || j >= hOffset+imageHSize){
				Buffer[(i*displayHSize*3)+(j*3)]   = 0x00;
			    Buffer[(i*displayHSize*3)+(j*3)+1] = 0x00;
			    Buffer[(i*displayHSize*3)+(j*3)+2] = 0x00;
			}
			else {
				Buffer[(i*displayHSize*3)+j*3]     = *imagePointer;
			    Buffer[(i*displayHSize*3)+(j*3)+1] = *imagePointer;
			    Buffer[(i*displayHSize*3)+(j*3)+2] = *imagePointer;
			    imagePointer++;
			}
		}
	}
	Xil_DCacheFlush();
	return XST_SUCCESS;
}

static int SD_Init(){
	FRESULT return_code;
	TCHAR *path = "0:/";

	return_code = f_mount(&filesystem, path, 0); //el cero es para no montar
	if(return_code){
		printf("Error initializing sd: %d\r\n", return_code);
		return XST_FAILURE;
	}
	return XST_SUCCESS;
}


static int readFile(char *file, u32 DestinationAddress){
	FIL file_object;
	FRESULT return_code;
	UINT br;

	return_code = f_open(&file_object, file, FA_READ);
	if(return_code){
		printf("Error opening file: %d\r\n", return_code);
		return XST_FAILURE;
	}

	return_code = f_lseek(&file_object,0);
	if(return_code){
		printf("Error lseek file: %d\r\n", return_code);
		return XST_FAILURE;
	}

	return_code = f_read(&file_object, (void *) DestinationAddress, f_size(&file_object), &br);
	if(return_code){
		printf("Error reading file: %d\r\n", return_code);
		return XST_FAILURE;
	}

	return_code = f_close(&file_object);
	if(return_code){
		printf("Error closing file: %d\r\n", return_code);
		return XST_FAILURE;
	}

	Xil_DCacheFlush();
	return XST_SUCCESS;

}

